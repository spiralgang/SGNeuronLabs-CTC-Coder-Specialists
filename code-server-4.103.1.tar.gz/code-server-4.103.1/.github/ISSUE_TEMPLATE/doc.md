---
name: Documentation improvement
about: Suggest a documentation improvement
labels: "docs"
---

## What is your suggestion?

## How will this improve the docs?

## Are you interested in submitting a PR for this?
