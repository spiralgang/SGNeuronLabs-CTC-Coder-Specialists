var main = require('./lib/main.js');

module.exports = function() {
  main(); // 执行主函数
}
