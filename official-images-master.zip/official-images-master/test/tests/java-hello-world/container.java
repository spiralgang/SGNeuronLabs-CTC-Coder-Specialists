public class container {
	/**
	 * Simple "hello world" to test the java can compile and/or run
	 */
	public static void main(String[] args) {
		System.out.println("Hello World!");
		System.exit(0);
	}
}
