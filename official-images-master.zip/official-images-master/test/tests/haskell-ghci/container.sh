#!/bin/bash
set -e

# Test that the REPL exists and 'works'.
echo | ghci
