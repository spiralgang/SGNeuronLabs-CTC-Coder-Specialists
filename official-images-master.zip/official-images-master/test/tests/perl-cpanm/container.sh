#!/bin/sh
set -eux

cpanm --notest Mojolicious
