#!/usr/bin/env sh
NAME=torch@vixalien.com
DIR=~/.local/share/gnome-shell/extensions/$NAME

mkdir -p $DIR
cp -r * $DIR
