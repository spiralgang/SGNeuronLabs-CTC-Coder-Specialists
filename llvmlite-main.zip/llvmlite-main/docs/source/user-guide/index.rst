==========
User guide
==========

.. toctree::
   :maxdepth: 2

   ir/index
   binding/index
   deprecation.rst
