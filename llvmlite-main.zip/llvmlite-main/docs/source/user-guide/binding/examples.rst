=====================================
Example---compiling a simple function
=====================================

.. currentmodule:: llvmlite.binding


Compile and execute the function defined in ``ir-fpadd.py``. 
For more information on ``ir-fpadd.py``, see 
:doc:`Example---Defining a simple function <../ir/examples>`.
The function is compiled with no specific optimizations.

.. literalinclude:: ../examples/ll_fpadd.py
