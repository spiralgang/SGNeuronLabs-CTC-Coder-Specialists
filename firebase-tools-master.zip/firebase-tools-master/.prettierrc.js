module.exports = {
  printWidth: 100,
};
