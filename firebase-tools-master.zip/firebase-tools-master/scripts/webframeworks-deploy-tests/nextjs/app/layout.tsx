export default function RootLayout({ children }: any) {
    return (
      <html>
        <head></head>
        <body>{children}</body>
      </html>
    )
}
