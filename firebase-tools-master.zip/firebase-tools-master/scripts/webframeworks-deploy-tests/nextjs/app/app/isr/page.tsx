export const revalidate = 60;

export default function ISR() {
    return <>ISR</>;
}
