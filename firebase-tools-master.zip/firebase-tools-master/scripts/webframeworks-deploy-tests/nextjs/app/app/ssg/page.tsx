export default function SSG() {
    return <>SSG</>;
}
