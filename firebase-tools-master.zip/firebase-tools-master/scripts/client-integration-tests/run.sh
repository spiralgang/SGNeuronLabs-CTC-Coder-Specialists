#!/bin/bash

source scripts/set-default-credentials.sh

mocha scripts/client-integration-tests/tests.ts