import { doSetup } from "./backend";

export { doSetup as setupBackend };
