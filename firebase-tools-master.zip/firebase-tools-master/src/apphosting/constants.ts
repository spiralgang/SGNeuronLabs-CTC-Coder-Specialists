export const DEFAULT_LOCATION = "us-central1";
export const DEFAULT_DEPLOY_METHOD = "github";
export const ALLOWED_DEPLOY_METHODS = [{ name: "Deploy using github", value: "github" }];
