module.exports = {
  printWidth: 80,
};
