const noop = () => {};

module.exports = noop;
