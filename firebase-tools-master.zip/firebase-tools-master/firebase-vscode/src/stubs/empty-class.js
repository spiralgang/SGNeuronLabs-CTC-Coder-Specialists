class Noop {}

module.exports = Noop;
