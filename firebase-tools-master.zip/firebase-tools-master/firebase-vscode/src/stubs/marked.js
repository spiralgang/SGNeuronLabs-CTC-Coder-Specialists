function marked() {}

marked.setOptions = () => {};

export { marked };
