// Set by the `package.json` file
export const isTest = !!process.env.TEST;
